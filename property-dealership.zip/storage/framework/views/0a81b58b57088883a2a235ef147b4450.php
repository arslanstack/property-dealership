<?php $__env->startPush('styles'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="row wrapper border-bottom white-bg page-heading">
	<div class="col-lg-8 col-sm-8 col-xs-8">
		<h2> Users Details </h2>
		<ol class="breadcrumb">
			<li class="breadcrumb-item">
				<a href="<?php echo e(url('admin')); ?>">Dashboard</a>
			</li>
			<li class="breadcrumb-item active">
				<strong> Users Details </strong>
			</li>
		</ol>
	</div>
	<div class="col-lg-4 col-sm-4 col-xs-4 text-right">
		<a class="btn btn-primary t_m_25" href="<?php echo e(url('admin/users')); ?>">
			<i class="fa fa-arrow-left" aria-hidden="true"></i> Back to Users
		</a>
	</div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
	<div class="row">
		<div class="col-lg-12">
			<div class="tabs-container">
				<ul class="nav nav-tabs" role="tablist">
					<li class="show_vehicle_tab"><a class="nav-link active show" data-toggle="tab" href="#tab-1">User Profile</a></li>
					<li class="show_bids_tab"><a class="nav-link" data-toggle="tab" href="#tab-2">User Products</a></li>
					<li class="show_req_tab"><a class="nav-link" data-toggle="tab" href="#tab-3">Product Requests</a></li>
				</ul>
				<div class="tab-content">
					<div id="tab-1" class="tab-pane active show" role="tabpanel">
						<div class="row">
							<div class="col-md-12">
								<div class="ibox">
									<div class="row ibox-content" style="border: none !important;">
										<div class="col-md-4">
											<div class="ibox-title" style="border: none !important;">
												<h5>Profile Image</h5>
											</div>
											<div>
												<div class="ibox-content p-4 border-left-right text-center">
													<img alt="image" class="img-fluid" src="<?php echo e(asset('assets/upload_images')); ?>/<?php echo e($user->image_name); ?>" style="width: 250px; height: 250px; object-fit:contain;">
												</div>
											</div>
										</div>
										<div class="col-md-8">
											<div class="ibox">
												<div class="ibox-title" style="border: none !important;">
													<h5>User Details</h5>
												</div>
												<div class="ibox-content">
													<div>
														<div class="feed-activity-list">
															<div class="row">
																<div class="col-lg-12">
																	<div class="row">
																		<strong class="col-sm-2 col-form-label">User Name</strong>
																		<div class="col-sm-4 col-form-label text-danger">
																			<?php echo e($user->name); ?>

																		</div>
																		<strong class="col-sm-2 col-form-label">Email</strong>
																		<div class="col-sm-4 col-form-label">
																			<?php echo e($user->email); ?>

																		</div>
																	</div>
																	<div class="row">
																		<strong class="col-sm-2 col-form-label">Phone No</strong>
																		<div class="col-sm-4 col-form-label">
																			<?php echo e($user->phone_no); ?>

																		</div>
																		<strong class="col-sm-2 col-form-label">City</strong>
																		<div class="col-sm-4 col-form-label">
																			<?php echo e($user->city ? $user->city->city_name : 'N/A'); ?>

																		</div>
																	</div>
																	<div class="row">
																		<strong class="col-sm-2 col-form-label">Address</strong>
																		<div class="col-sm-4 col-form-label">
																			<?php echo e($user->address ? $user->address : 'N/A'); ?>

																		</div>
																		<strong class="col-sm-2 col-form-label">Zip Code</strong>
																		<div class="col-sm-4 col-form-label">
																			<?php echo e($user->zip ? $user->zip : 'N/A'); ?>

																		</div>
																	</div>
																	<div class="row">
																		<strong class="col-sm-2 col-form-label">Joining Date</strong>
																		<div class="col-sm-4 col-form-label">
																			<?php echo e(date_formated($user->created_at)); ?>

																		</div>
																		<strong class="col-sm-2 col-form-label">Status</strong>
																		<div class="col-sm-4 col-form-label">
																			<?php if($user->is_blocked == 1): ?>
																			<label class="label label-danger"> Blocked </label>
																			<?php else: ?>
																			<?php if($user->status==1): ?>
																			<label class="label label-primary"> Active </label>
																			<?php else: ?>
																			<label class="label label-warning"> Inactive </label>
																			<?php endif; ?>
																		</div>

																		<?php endif; ?>
																	</div>
																	<div class="row">
																		<strong class="col-sm-2 col-form-label">Total Products</strong>
																		<div class="col-sm-4 col-form-label text-left">
																			<?php echo e(count_user_posts($user->id) > 0 ? count_user_posts($user->id) : 'N/A'); ?>

																		</div>
																		<strong class="col-sm-2 col-form-label">Product Requests</strong>
																		<div class="col-sm-4 col-form-label text-left">
																			<?php echo e(count_user_requests($user->id) > 0 ? count_user_requests($user->id) : 'N/A'); ?>

																		</div>
																	</div>
																	<div class="row">
																		<strong class="col-sm-2 col-form-label">Total Favourites</strong>
																		<div class="col-sm-4 col-form-label text-left">
																			<?php echo e(count_user_favourites($user->id) > 0 ? count_user_favourites($user->id) : 'N/A'); ?>

																		</div>
																		<strong class="col-sm-2 col-form-label">Total Chats</strong>
																		<div class="col-sm-4 col-form-label text-left">
																			<?php echo e(count_user_chat_threads($user->id) > 0 ? count_user_chat_threads($user->id) : 'N/A'); ?>

																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div id="tab-2" class="tab-pane" role="tabpanel">
						<div class="ibox">
							<div class="ibox-title">
								<h5>User Products</h5>
							</div>
							<div class="ibox-content">
								<div class="table-responsive">
									<table id="manage_tbl" class="table table-striped table-bordered dt-responsive" style="width:100%">
										<thead>
											<tr>
												<th>Sr #</th>
												<th>Title</th>
												<th>Favourites</th>
												<th>Creation Date</th>
												<th>Status</th>
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
											<?php ($i = 1); ?>
											<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr class="gradeX">
												<td><?php echo e($i++); ?></td>
												<td><?php echo e(\Illuminate\Support\Str::limit($item->title, 60, '...')); ?></td>
												<td><?php echo e(count_post_favs($item->id) > 0 ? count_post_favs($item->id) : 'N/A'); ?></td>
												<td><?php echo e(date_formated($item->created_at)); ?></td>
												<td>
													<?php if($item->status == 0): ?>
													<label class="label label-danger"> Disabled </label>
													<?php else: ?>
													<label class="label label-primary"> Active </label>
													<?php endif; ?>
												</td>
												<td>
													<a class="btn btn-primary btn-sm" href="<?php echo e(url('admin/product-posts/detail')); ?>/<?php echo e($item->id); ?>">Details</a>
													<!-- <button class="btn btn-danger btn-sm btn_delete" data-id="<?php echo e($item->id); ?>" data-text="This action will delete this category." type="button" data-placement="top" title="Delete">Delete</button> -->
													<?php if($item->status==1): ?>
													<button class="btn btn-danger btn-sm btn_update_status" data-id="<?php echo e($item->id); ?>" data-status="0" data-text="This action will disable this post and hide it from users' timeline." type="button" data-placement="top" title="Inactivate">Disable</button>
													<?php else: ?>
													<button class="btn btn-success btn-sm btn_update_status" data-id="<?php echo e($item->id); ?>" data-status="1" data-text="This action will enable this post and start showing it in users' timeline." type="button" data-placement="top" title="Activate">Enable</button>
													<?php endif; ?>
												</td>
											</tr>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
					<div id="tab-3" class="tab-pane" role="tabpanel">
						<div class="ibox">
							<div class="ibox-title">
								<h5>Product Requests</h5>
							</div>
							<div class="ibox-content">
								<div class="table-responsive">
									<table id="manage_tbl_two" class="table table-striped table-bordered dt-responsive" style="width:100%">
										<thead>
											<tr>
												<th>Sr #</th>
												<th>Title</th>
												<th>Favourites</th>
												<th>Creation Date</th>
												<th>Status</th>
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
											<?php ($i = 1); ?>
											<?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr class="gradeX">
												<td><?php echo e($i++); ?></td>
												<td><?php echo e(\Illuminate\Support\Str::limit($item->title, 60, '...')); ?></td>
												<td><?php echo e(count_request_favs($item->id) > 0 ? count_request_favs($item->id) : 'N/A'); ?></td>
												<td><?php echo e(date_formated($item->created_at)); ?></td>
												<td>
													<?php if($item->status == 0): ?>
													<label class="label label-danger"> Disabled </label>
													<?php else: ?>
													<label class="label label-primary"> Active </label>
													<?php endif; ?>
												</td>
												<td>
													<a class="btn btn-primary btn-sm" href="<?php echo e(url('admin/product-requests/detail')); ?>/<?php echo e($item->id); ?>">Details</a>
													<!-- <button class="btn btn-danger btn-sm btn_delete" data-id="<?php echo e($item->id); ?>" data-text="This action will delete this category." type="button" data-placement="top" title="Delete">Delete</button> -->
													<?php if($item->status==1): ?>
													<button class="btn btn-danger btn-sm btn_update_status_requests" data-id="<?php echo e($item->id); ?>" data-status="0" data-text="This action will disable this post and hide it from users' timeline." type="button" data-placement="top" title="Inactivate">Disable</button>
													<?php else: ?>
													<button class="btn btn-success btn-sm btn_update_status_requests" data-id="<?php echo e($item->id); ?>" data-status="1" data-text="This action will enable this post and start showing it in users' timeline." type="button" data-placement="top" title="Activate">Enable</button>
													<?php endif; ?>
												</td>
											</tr>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
	document.addEventListener('DOMContentLoaded', function() {
		var tabLinks = document.querySelectorAll('.nav-tabs a.nav-link');
		tabLinks.forEach(function(tabLink) {
			tabLink.addEventListener('click', function(event) {
				event.preventDefault();
				var targetTabId = tabLink.getAttribute('href');
				var tabParamsMap = {
					'#tab-1': 'profile',
					'#tab-2': 'products',
					'#tab-3': 'requests'
				};
				var tabParam = tabParamsMap[targetTabId];
				var currentUrl = new URL(window.location.href);
				currentUrl.searchParams.set('tab', tabParam);
				history.replaceState(null, null, currentUrl);
				$(targetTabId).tab('show');
			});
		});
		var urlParams = new URLSearchParams(window.location.search);
		var tabParam = urlParams.get('tab');
		if (tabParam) {
			var tabIdsMap = {
				'profile': '#tab-1',
				'products': '#tab-2',
				'requests': '#tab-3'
			};
			var tabId = tabIdsMap[tabParam];
			$('a[href="' + tabId + '"]').tab('show');
		}
	});

	$(document).on('click', '.show_bids_tab', function() {
		if (!($("table#manage_tbl").hasClass("dataTable"))) {
			$('#manage_tbl').dataTable({
				"paging": true,
				"searching": true,
				"bInfo": true,
				"responsive": true,
				"pageLength": 50,
				"columnDefs": [{
						"responsivePriority": 1,
						"targets": 0
					},
					{
						"responsivePriority": 2,
						"targets": -1
					},
				]
			});
		}
	});
	$(document).on('click', '.show_req_tab', function() {
		if (!($("table#manage_tbl_two").hasClass("dataTable"))) {
			$('#manage_tbl_two').dataTable({
				"paging": true,
				"searching": true,
				"bInfo": true,
				"responsive": true,
				"pageLength": 50,
				"columnDefs": [{
						"responsivePriority": 1,
						"targets": 0
					},
					{
						"responsivePriority": 2,
						"targets": -1
					},
				]
			});
		}
	});


	$(document).on("click", ".btn_update_status", function() {
		var id = $(this).attr('data-id');
		var status = $(this).attr('data-status');
		var show_text = $(this).attr('data-text');
		swal({
				title: "Are you sure?",
				text: show_text,
				type: "warning",
				showCancelButton: true,
				confirmButtonColor: "#DD6B55",
				confirmButtonText: "Yes, Please!",
				cancelButtonText: "No, Cancel Please!",
				closeOnConfirm: false,
				closeOnCancel: true
			},
			function(isConfirm) {
				if (isConfirm) {
					$(".confirm").prop("disabled", true);
					$.ajax({
						url: "<?php echo e(url('admin/product-posts/update_statuses')); ?>",
						type: 'post',
						data: {
							"_token": "<?php echo e(csrf_token()); ?>",
							'id': id,
							'status': status
						},
						dataType: 'json',
						success: function(status) {
							$(".confirm").prop("disabled", false);
							if (status.msg == 'success') {
								swal({
										title: "Success!",
										text: status.response,
										type: "success"
									},
									function(data) {
										location.reload();
									});
							} else if (status.msg == 'error') {
								swal("Error", status.response, "error");
							}
						}
					});
				} else {
					swal("Cancelled", "", "error");
				}
			});
	});
	$(document).on("click", ".btn_update_status_requests", function() {
		var id = $(this).attr('data-id');
		var status = $(this).attr('data-status');
		var show_text = $(this).attr('data-text');
		swal({
				title: "Are you sure?",
				text: show_text,
				type: "warning",
				showCancelButton: true,
				confirmButtonColor: "#DD6B55",
				confirmButtonText: "Yes, Please!",
				cancelButtonText: "No, Cancel Please!",
				closeOnConfirm: false,
				closeOnCancel: true
			},
			function(isConfirm) {
				if (isConfirm) {
					$(".confirm").prop("disabled", true);
					$.ajax({
						url: "<?php echo e(url('admin/product-requests/update_statuses')); ?>",
						type: 'post',
						data: {
							"_token": "<?php echo e(csrf_token()); ?>",
							'id': id,
							'status': status
						},
						dataType: 'json',
						success: function(status) {
							$(".confirm").prop("disabled", false);
							if (status.msg == 'success') {
								swal({
										title: "Success!",
										text: status.response,
										type: "success"
									},
									function(data) {
										location.reload();
									});
							} else if (status.msg == 'error') {
								swal("Error", status.response, "error");
							}
						}
					});
				} else {
					swal("Cancelled", "", "error");
				}
			});
	});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\mandi-links\resources\views/admin/users/users_details.blade.php ENDPATH**/ ?>