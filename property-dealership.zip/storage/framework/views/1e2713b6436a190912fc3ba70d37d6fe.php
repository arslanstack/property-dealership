<nav class="navbar-default navbar-static-side" role="navigation">
    <div class="sidebar-collapse">
        <ul class="nav metismenu" id="side-menu">
            <li class="nav-header">
                <div class="dropdown profile-element">
                    <img alt="image" class="rounded-circle" style="width: 50px;" src="<?php echo e(asset('admin_assets/img/profile_small.jpg')); ?>"/>
                    <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                        <span class="block m-t-xs font-bold">Welcome <?php echo e(ucwords(Auth::guard('admin')->user()->username)); ?></span>
                        <span class="text-muted text-xs block">
                            <?php echo e(get_section_content('project', 'site_title')); ?>

                        </span>
                    </a>
                </div>
                <div class="logo-element">
                    <?php echo e(ucwords(Auth::guard('admin')->user()->username)); ?>

                    <span class="text-muted text-xs block">
                        <?php echo e(get_section_content('project', 'short_site_title')); ?>

                    </span>
                </div>
            </li>
            <li class="<?php echo e(Request::is('admin') ? 'active' : ''); ?> <?php echo e(Request::is('admin/admin') ? 'active' : ''); ?> <?php echo e(Request::is('admin/change_password') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('admin')); ?>"><i class="fa-solid fa-gauge-high"></i> <span class="nav-label">Dashboard</span></a>
            </li>
            <li class="<?php echo e(Request::is('admin/users') ? 'active' : ''); ?> <?php echo e(Request::is('admin/users/detail*') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('admin/users')); ?>"><i class="fa-solid fa-users"></i> <span class="nav-label">Users</span></a>
            </li>
            <li class="<?php echo e(Request::is('admin/categories') ? 'active' : ''); ?> <?php echo e(Request::is('admin/categories/*') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('admin/categories')); ?>"><i class="fa-solid fa-table"></i> <span class="nav-label">Categories</span></a>
            </li>
            <li class="<?php echo e(Request::is('admin/product-posts') ? 'active' : ''); ?> <?php echo e(Request::is('admin/product-posts/*') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('admin/product-posts')); ?>"><i class="fa-brands fa-product-hunt"></i> <span class="nav-label">Products</span></a>
            </li>
            <li class="<?php echo e(Request::is('admin/product-requests') ? 'active' : ''); ?> <?php echo e(Request::is('admin/product-requests/*') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('admin/product-requests')); ?>"><i class="fa-solid fa-person-circle-question"></i> <span class="nav-label">Product Requests</span></a>
            </li>
            <li class="<?php echo e(Request::is('admin/blogs') ? 'active' : ''); ?> <?php echo e(Request::is('admin/blogs/*') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('admin/blogs')); ?>"><i class="fa-solid fa-square-rss"></i> <span class="nav-label">Blogs</span></a>
            </li>
        </ul>
    </div>
</nav><?php /**PATH E:\xampp\htdocs\mandi-links\resources\views/common/admin_sidebar.blade.php ENDPATH**/ ?>