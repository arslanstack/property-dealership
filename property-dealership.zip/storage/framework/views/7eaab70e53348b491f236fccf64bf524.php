<?php $__env->startPush('styles'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-8 col-sm-8 col-xs-8">
        <h2> Product Details </h2>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(url('admin')); ?>">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">
                <strong> Product Details </strong>
            </li>
        </ol>
    </div>
    <div class="col-lg-4 col-sm-4 col-xs-4 text-right">
        <a class="btn btn-primary t_m_25" href="<?php echo e(url()->previous()); ?>">
            <i class="fa fa-arrow-left" aria-hidden="true"></i>
            <?php if(Str::contains(url()->previous(), 'admin/users/detail')): ?>
            Back to User Details
            <?php else: ?>
            Back to Products
            <?php endif; ?>
        </a>
    </div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
        <div class="col-lg-12">
            <div class="tabs-container">
                <div class="tab-content">
                    <div id="tab-1" class="tab-pane active show" role="tabpanel">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="ibox">
                                    <div class="row ibox-content" style="border: none !important;">
                                        <div class="col-md-4">
                                            <div class="ibox-title" style="border: none !important;">
                                                <h5>Product Images</h5>
                                            </div>
                                            <div>
                                                <div class="ibox-content p-4 border-left-right text-center">
                                                    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                                                        <ol class="carousel-indicators">
                                                            <?php ($i = 0) ?>
                                                            <?php $__currentLoopData = array_slice($post->images, 0, 6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($i); ?>" <?php if($i==0): ?> class="active" <?php endif; ?>></li>
                                                            <?php ($i++) ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </ol>
                                                        <div class="carousel-inner">
                                                            <?php ($i = 0) ?>
                                                            <?php $__currentLoopData = $post->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="carousel-item <?php if($i == 0): ?> active <?php endif; ?>">
                                                                <img class="d-block w-100" src="<?php echo e($image); ?>" alt="First slide" draggable="false" (dragstart)="false;" class="unselectable" style="width: 300px; height: 300px; object-fit: contain;">
                                                            </div>
                                                            <?php ($i++) ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </div>
                                                        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                                                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                                            <span class="sr-only">Previous</span>
                                                        </a>
                                                        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                                                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                                            <span class="sr-only">Next</span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-8">
                                            <div class="ibox-title" style="border: none !important;">
                                                <h5>Product Details</h5>
                                                <span class="float-right"><i class="fa-solid fa-heart"></i> <?php echo e(count_post_favs($post->id)); ?></span>
                                            </div>
                                            <div class="ibox-content">
                                                <div>
                                                    <div class="feed-activity-list">
                                                        <div class="row">
                                                            <div class="col-lg-12">
                                                                <div class="row">
                                                                    <strong class="col-sm-2 col-form-label">Vendor</strong>
                                                                    <div class="col-sm-4 col-form-label">
                                                                        <a href="<?php echo e(url('admin/users/detail/' . $post->Vendor->id)); ?>" target="_blank"><?php echo e($post->Vendor->name); ?> <i class="fa-solid fa-up-right-from-square"></i></a>
                                                                    </div>
                                                                    <strong class="col-sm-3 col-form-label">Vendor Location</strong>
                                                                    <div class="col-sm-3 col-form-label">
                                                                        <?php echo e($post->vendor_location); ?>

                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <strong class="col-sm-2 col-form-label">Title</strong>
                                                                    <div class="col-sm-4 col-form-label text-danger">
                                                                        <?php echo e($post->title); ?>

                                                                    </div>
                                                                    <strong class="col-sm-3 col-form-label">Product Location</strong>
                                                                    <div class="col-sm-3 col-form-label">
                                                                        <?php echo e($post->product_location); ?>

                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <strong class="col-sm-2 col-form-label">Quantity</strong>
                                                                    <div class="col-sm-4 col-form-label">
                                                                        <?php echo e($post->quantity); ?>

                                                                    </div><strong class="col-sm-3 col-form-label">Unit</strong>
                                                                    <div class="col-sm-3 col-form-label">
                                                                        <?php echo e($post->unit); ?>

                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <strong class="col-sm-2 col-form-label">Price</strong>
                                                                    <div class="col-sm-4 col-form-label">
                                                                        PKR <?php echo e($post->price); ?> / <?php echo e($post->unit); ?>

                                                                    </div>
                                                                    <strong class="col-sm-3 col-form-label">Brand</strong>
                                                                    <div class="col-sm-3 col-form-label">
                                                                        <?php echo e($post->brand ? $post->brand : 'N/A'); ?>

                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <strong class="col-sm-2 col-form-label">Category</strong>
                                                                    <div class="col-sm-4 col-form-label">
                                                                        <?php echo e($post->category); ?>

                                                                    </div>
                                                                    <strong class="col-sm-3 col-form-label">Subcategory</strong>
                                                                    <div class="col-sm-3 col-form-label">
                                                                        <?php echo e($post->subcategory); ?>

                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <strong class="col-sm-2 col-form-label">Moisture</strong>
                                                                    <div class="col-sm-4 col-form-label">
                                                                        <?php echo e($post->moisture ? $post->moisture : 'N/A'); ?>%
                                                                    </div>
                                                                    <strong class="col-sm-3 col-form-label">Place of Origin</strong>
                                                                    <div class="col-sm-3 col-form-label">
                                                                        <?php echo e($post->place_of_origin ? $post->place_of_origin : 'N/A'); ?>

                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <strong class="col-sm-2 col-form-label">Model No</strong>
                                                                    <div class="col-sm-4 col-form-label">
                                                                        <?php echo e($post->model_no ? $post->model_no : 'N/A'); ?>

                                                                    </div>
                                                                    <strong class="col-sm-3 col-form-label">Certification</strong>
                                                                    <div class="col-sm-3 col-form-label">
                                                                        <?php echo e($post->certification ? $post->certification : 'N/A'); ?>

                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <strong class="col-sm-2 col-form-label">Added On</strong>
                                                                    <div class="col-sm-4 col-form-label">
                                                                        <?php echo e(\Carbon\Carbon::parse($post->created_at)->format('j F Y')); ?>

                                                                    </div>
                                                                    <strong class="col-sm-3 col-form-label">Status</strong>
                                                                    <div class="col-sm-3 col-form-label">
                                                                        <?php if($post->status == 0): ?>
                                                                        <label class="label label-danger"> Disabled </label>
                                                                        <?php else: ?>
                                                                        <label class="label label-primary"> Active </label>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="ibox-title" style="border: none !important;">
                                                <h5>Product Description</h5>
                                            </div>
                                            <div class="ibox-content">
                                                <div>
                                                    <div class="feed-activity-list">
                                                        <div class="row">
                                                            <div class="col-lg-12">
                                                                <div class="row">
                                                                    <div class="col-sm-12 col-form-label">
                                                                        <?php echo e($post->description ? $post->description : 'N/A'); ?>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\mandi-links\resources\views/admin/posts/post_details.blade.php ENDPATH**/ ?>