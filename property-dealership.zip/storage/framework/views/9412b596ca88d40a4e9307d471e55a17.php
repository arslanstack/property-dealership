<?php echo $__env->yieldPushContent('styles'); ?>
<link href="<?php echo e(asset('admin_assets/css/bootstrap.min.css')); ?>" rel="stylesheet">

<link href="<?php echo e(asset('admin_assets/fontawesome-free-6.4.2/css/all.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('admin_assets/css/plugins/sweetalert/sweetalert.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('admin_assets/css/plugins/toastr/toastr.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('admin_assets/css/plugins/ladda/ladda-themeless.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('admin_assets/css/plugins/datapicker/datepicker3.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('admin_assets/css/datatable/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('admin_assets/css/datatable/responsive.bootstrap4.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('admin_assets/css/plugins/select2/select2.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('admin_assets/css/plugins/bootstrap-tagsinput/bootstrap-tagsinput.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('admin_assets/build/css/intlTelInput.css')); ?>" rel="stylesheet">

<link href="<?php echo e(asset('admin_assets/css/plugins/iCheck/custom.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('admin_assets/css/custom.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('admin_assets/css/animate.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('admin_assets/css/style.css')); ?>" rel="stylesheet">
<link rel="shortcut icon" href="<?php echo e(asset('admin_assets/img/favicon.png')); ?>" type="image/x-icon"><?php /**PATH E:\xampp\htdocs\mandi-links\resources\views/common/admin_header.blade.php ENDPATH**/ ?>