<nav class="navbar-default navbar-static-side" role="navigation">
    <div class="sidebar-collapse">
        <ul class="nav metismenu" id="side-menu">
            <li class="nav-header">
                <div class="dropdown profile-element">
                    <img alt="image" class="rounded-circle" style="width: 50px;" src="<?php echo e(asset('admin_assets/img/profile_small.jpg')); ?>" />
                    <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                        <span class="block m-t-xs font-bold">Welcome <?php echo e(ucwords(Auth::guard('admin')->user()->username)); ?></span>
                        <span class="text-muted text-xs block">
                            <?php echo e(get_section_content('project', 'site_title')); ?>

                        </span>
                    </a>
                </div>
                <div class="logo-element">
                    <?php echo e(ucwords(Auth::guard('admin')->user()->username)); ?>

                    <span class="text-muted text-xs block">
                        <?php echo e(get_section_content('project', 'short_site_title')); ?>

                    </span>
                </div>
            </li>
            <li class="<?php echo e(Request::is('admin') ? 'active' : ''); ?> <?php echo e(Request::is('admin/admin') ? 'active' : ''); ?> <?php echo e(Request::is('admin/change_password') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('admin')); ?>"><i class="fa-solid fa-gauge-high"></i> <span class="nav-label">Dashboard</span></a>
            </li>
            <li class="<?php echo e(Request::is('admin/users') ? 'active' : ''); ?> <?php echo e(Request::is('admin/users/detail*') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('admin/users')); ?>"><i class="fa-solid fa-users"></i> <span class="nav-label">Users Management</span></a>
            </li>
            <li class="<?php echo e(Request::is('admin/types') ? 'active' : ''); ?> <?php echo e(Request::is('admin/types/detail*') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('admin/types')); ?>"><i class="fa-solid fa-tags"></i> <span class="nav-label">Property Types</span></a>
            </li>
            <li class="<?php echo e(Request::is('admin/features') ? 'active' : ''); ?> <?php echo e(Request::is('admin/features/detail*') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('admin/features')); ?>"><i class="fa-solid fa-tasks"></i> <span class="nav-label">Property Features</span></a>
            </li>
            <li class="<?php echo e(Request::is('admin/neighborhoods') ? 'active' : ''); ?> <?php echo e(Request::is('admin/neighborhoods/*') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('admin/neighborhoods')); ?>"><i class="fa-solid fa-location-arrow"></i> <span class="nav-label">Neighborhoods</span></a>
            </li>
            <li class="<?php echo e(Request::is('admin/property-listings') ? 'active' : ''); ?> <?php echo e(Request::is('admin/property-listings/*') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('admin/property-listings')); ?>"><i class="fa-solid fa-th"></i> <span class="nav-label">Property Listings</span></a>
            </li>
        </ul>
    </div>
</nav><?php /**PATH E:\xampp\htdocs\property-dealership\resources\views/common/admin_sidebar.blade.php ENDPATH**/ ?>