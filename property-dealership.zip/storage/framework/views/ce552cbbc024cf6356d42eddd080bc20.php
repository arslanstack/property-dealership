<div class="footer">
    <div>
        <strong>Copyright</strong> <?php echo e(get_section_content('project', 'site_title')); ?> &copy; <?php echo e(date("Y")); ?>

        Developed by - <a href="https://explorelogics.com/" target="_blank">Explore Logics </a>
    </div>
</div><?php /**PATH E:\xampp\htdocs\property-dealership\resources\views/common/admin_footer.blade.php ENDPATH**/ ?>