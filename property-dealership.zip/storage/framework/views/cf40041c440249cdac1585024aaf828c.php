<?php $__env->startSection('content'); ?>
<div class="wrapper wrapper-content animated fadeIn">
	<div class="row">
		<div class="col-lg-3">
			<div class="ibox float-e-margins">
				<div class="ibox-title">
					<span class="label label-success pull-right">Total</span>
					<h5>Client Users</h5>
				</div>
				<div class="ibox-content">
					<h1 class="no-margins">12</h1>
					<div class="stat-percent font-bold text-primary"><a href="<?php echo e(url('admin/users')); ?>"><span class="label label-primary">View</span></a></div>
					<small>Client Users</small>
				</div>
			</div>
		</div>
		<div class="col-lg-3">
			<div class="ibox float-e-margins">
				<div class="ibox-title">
					<span class="label label-success pull-right">Total</span>
					<h5>Property Listings</h5>
				</div>
				<div class="ibox-content">
					<h1 class="no-margins">12</h1>
					<div class="stat-percent font-bold text-primary"><a href="<?php echo e(url('admin/properties')); ?>"><span class="label label-primary">View</span></a></div>
					<small>Property Listings</small>
				</div>
			</div>
		</div>
		<div class="col-lg-3">
			<div class="ibox float-e-margins">
				<div class="ibox-title">
					<span class="label label-success pull-right">Total</span>
					<h5>Property Features</h5>
				</div>
				<div class="ibox-content">
					<h1 class="no-margins">12</h1>
					<div class="stat-percent font-bold text-primary"><a href="<?php echo e(url('admin/features')); ?>"><span class="label label-primary">View</span></a></div>
					<small>Property Features</small>
				</div>
			</div>
		</div>
		<div class="col-lg-3">
			<div class="ibox float-e-margins">
				<div class="ibox-title">
					<span class="label label-success pull-right">Total</span>
					<h5>Property Types</h5>
				</div>
				<div class="ibox-content">
					<h1 class="no-margins">12</h1>
					<div class="stat-percent font-bold text-primary"><a href="<?php echo e(url('admin/types')); ?>"><span class="label label-primary">View</span></a></div>
					<small>Property Types</small>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\property-dealership\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>